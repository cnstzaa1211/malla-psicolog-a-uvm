
const ramos = [
  // Semestre 1
  {sem: 1, codigo: 'TIF', nombre: 'Taller de Introducción a la Profesión', prerreq: []},
  {sem: 1, codigo: 'HPC', nombre: 'Historia y Procesos Culturales', prerreq: []},
  {sem: 1, codigo: 'EPG', nombre: 'Epistemología', prerreq: []},
  {sem: 1, codigo: 'EGG', nombre: 'Ejes de Gestión General', prerreq: []},

  // Semestre 2
  {sem: 2, codigo: 'TIP', nombre: 'Taller de Introducción a la Psicología', prerreq: ['TIF']},
  {sem: 2, codigo: 'PSI', nombre: 'Psicología General', prerreq: []},
  {sem: 2, codigo: 'SDS', nombre: 'Sociedad y Desarrollo Social', prerreq: []},
  {sem: 2, codigo: 'EE', nombre: 'Estrategias de Evaluación', prerreq: []},

  // Semestre 3
  {sem: 3, codigo: 'PSF', nombre: 'Psicofisiología', prerreq: ['PSI']},
  {sem: 3, codigo: 'TEO', nombre: 'Teorías Psicológicas Contemporáneas', prerreq: []},
  {sem: 3, codigo: 'MET', nombre: 'Metodología Cuantitativa', prerreq: []},
  {sem: 3, codigo: 'ING1', nombre: 'Inglés I', prerreq: []},

  // Semestre 4
  {sem: 4, codigo: 'PDC', nombre: 'Psicología del Ciclo Vital I', prerreq: []},
  {sem: 4, codigo: 'ENT', nombre: 'Entrevista', prerreq: []},
  {sem: 4, codigo: 'DPC', nombre: 'Desarrollo Personal y Comunicación', prerreq: []},
  {sem: 4, codigo: 'ING2', nombre: 'Inglés II', prerreq: ['ING1']},

  // Semestre 5
  {sem: 5, codigo: 'PCV2', nombre: 'Psicología del Ciclo Vital II', prerreq: ['PDC']},
  {sem: 5, codigo: 'TRA', nombre: 'Trastornos Psicológicos', prerreq: []},
  {sem: 5, codigo: 'METC', nombre: 'Metodología Cualitativa', prerreq: []},
  {sem: 5, codigo: 'ING3', nombre: 'Inglés III', prerreq: ['ING2']},

  // Semestre 6
  {sem: 6, codigo: 'PSOC', nombre: 'Psicología Social', prerreq: []},
  {sem: 6, codigo: 'NEU', nombre: 'Neuropsicología', prerreq: ['PSF']},
  {sem: 6, codigo: 'PRC', nombre: 'Procesos Cognitivos', prerreq: []},
  {sem: 6, codigo: 'ING4', nombre: 'Inglés IV', prerreq: ['ING3']},

  // Semestre 7
  {sem: 7, codigo: 'PSICM', nombre: 'Psicometría', prerreq: []},
  {sem: 7, codigo: 'PCL', nombre: 'Psicología Clínica', prerreq: []},
  {sem: 7, codigo: 'ORG', nombre: 'Psicología Organizacional', prerreq: []},

  // Semestre 8
  {sem: 8, codigo: 'COM', nombre: 'Psicología Comunitaria', prerreq: []},
  {sem: 8, codigo: 'INF', nombre: 'Psicología Infantil', prerreq: []},
  {sem: 8, codigo: 'ADO', nombre: 'Psicología del Adolescente', prerreq: []}
];

const cursados = new Set();

function crearTarjeta(ramo) {
  const div = document.createElement("div");
  div.className = "ramo";
  div.innerHTML = `<input type="checkbox" onchange="toggleRamo('${ramo.codigo}')"> ${ramo.nombre}`;
  div.dataset.codigo = ramo.codigo;
  div.dataset.sem = ramo.sem;
  return div;
}

function toggleRamo(codigo) {
  if (cursados.has(codigo)) {
    cursados.delete(codigo);
  } else {
    cursados.add(codigo);
  }
  updateUI();
}

function updateUI() {
  ramos.forEach(ramo => {
    const box = document.querySelector(`[data-codigo="${ramo.codigo}"] input`);
    box.checked = cursados.has(ramo.codigo);
  });
  const porcentaje = Math.round((cursados.size / ramos.length) * 100);
  const avanceDiv = document.getElementById("avance");
  avanceDiv.textContent = `Avance: ${cursados.size} de ${ramos.length} ramos cursados (${porcentaje}%)`;
}

window.onload = () => {
  const mallaDiv = document.getElementById("malla");
  for (let i = 1; i <= 8; i++) {
    const columna = document.createElement("div");
    columna.className = "semestre";
    columna.innerHTML = `<h2>Semestre ${i}</h2>`;
    ramos.filter(r => r.sem === i).forEach(ramo => {
      columna.appendChild(crearTarjeta(ramo));
    });
    mallaDiv.appendChild(columna);
  }
  updateUI();
};
